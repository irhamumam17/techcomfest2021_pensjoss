package com.ardianbagus.karyain

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
