```shell
# install dependency
$ flutter pub get
```